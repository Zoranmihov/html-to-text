#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -x "$DIR/jre/bin/java" ]; then
  JAVA="$DIR/jre/bin/java"
elif [ -n "${JAVA_HOME:-}" ] && [ -x "${JAVA_HOME}/bin/java" ]; then
  JAVA="${JAVA_HOME}/bin/java"
else
  JAVA="java"
fi

exec "$JAVA" -jar "$DIR/lib/html-to-text-1.0.0-all.jar"
